#pragma once

#include "T20_Mfcc_Inter_072.h"

void T20_registerWebHandlers(CL_T20_Mfcc::ST_Impl* p, AsyncWebServer* v_server, const char* p_base_path);
