#include "T20_Mfcc_Inter_047.h"

#include <SD_MMC.h>
#include <FS.h>

/*
===============================================================================
소스명: T20_Mfcc_Recorder_047.cpp
버전: v047

[기능 스펙]
- SD_MMC recorder 전용 queue/task
- session 디렉터리 생성
- binary raw header 설계/구현
- event/raw/feature 비동기 기록
- batching drain + 주기 flush
- metadata heartbeat 기록

[이번 단계 큰 다음 진행]
- recorder queue/task 구조를 유지하면서 파일 핸들을 세션 동안 유지
- queue를 한 번 깨울 때 여러 건(batch) 처리
- flush 주기와 metadata 주기를 설정값으로 제어
- AsyncWeb 다운로드와 바로 연결 가능한 세션 파일 경로 유지

[향후 단계 TODO]
- 압축/요약 저장
- recorder 오류 상태 통계 고도화
- 다중 세션 정리 정책 고도화
- binary block batching + CRC
===============================================================================
*/

static bool T20_writeTextLineToOpenFile(File& p_file, const char* p_line)
{
    if (!p_file || p_line == nullptr) {
        return false;
    }

    p_file.println(p_line);
    return true;
}


static bool T20_recorderReopenSessionFiles(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return false;
    }

    if (p->recorder.raw_file)     p->recorder.raw_file.close();
    if (p->recorder.meta_file)    p->recorder.meta_file.close();
    if (p->recorder.event_file)   p->recorder.event_file.close();
    if (p->recorder.feature_file) p->recorder.feature_file.close();

    p->recorder.raw_file     = SD_MMC.open(p->recorder.raw_path, FILE_APPEND);
    p->recorder.meta_file    = SD_MMC.open(p->recorder.meta_path, FILE_APPEND);
    p->recorder.event_file   = SD_MMC.open(p->recorder.event_path, FILE_APPEND);
    p->recorder.feature_file = SD_MMC.open(p->recorder.feature_path, FILE_APPEND);

    return (bool)p->recorder.raw_file &&
           (bool)p->recorder.meta_file &&
           (bool)p->recorder.event_file &&
           (bool)p->recorder.feature_file;
}

bool T20_recorderTryRecover(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return false;
    }

    const uint32_t v_now = millis();
    if ((v_now - p->recorder.last_recovery_ms) < G_T20_RECORDER_RECOVERY_RETRY_DELAY_MS) {
        return false;
    }

    p->recorder.last_recovery_ms = v_now;

    for (uint32_t i = 0; i < G_T20_RECORDER_RECOVERY_RETRY_MAX; ++i) {
        p->recorder.recovery_retry_count++;
        if (T20_recorderReopenSessionFiles(p)) {
            T20_recorderSetLastError(p, "");
            p->recorder.session_open = true;
            return true;
        }
        delay(10);
    }

    p->recorder.recovery_fail_count++;
    T20_recorderSetLastError(p, "reopen_failed");
    p->recorder.session_open = false;
    return false;
}


static bool T20_writeBinaryRawRecordToOpenFile(File& p_file,
                                               uint32_t p_timestamp_ms,
                                               const float* p_samples,
                                               uint16_t p_sample_count)
{
    if (!p_file || p_samples == nullptr || p_sample_count == 0) {
        return false;
    }

    ST_T20_RecorderRecordHeader_t hdr;
    hdr.magic = G_T20_RECORDER_RECORD_MAGIC;
    hdr.record_type = (uint16_t)EN_T20_REC_RECORD_RAW_FRAME;
    hdr.payload_bytes = (uint16_t)(sizeof(uint16_t) + sizeof(float) * p_sample_count);
    hdr.timestamp_ms = p_timestamp_ms;

    size_t w1 = p_file.write(reinterpret_cast<const uint8_t*>(&hdr), sizeof(hdr));
    size_t w2 = p_file.write(reinterpret_cast<const uint8_t*>(&p_sample_count), sizeof(p_sample_count));
    size_t w3 = p_file.write(reinterpret_cast<const uint8_t*>(p_samples), sizeof(float) * p_sample_count);

    return (w1 == sizeof(hdr) &&
            w2 == sizeof(p_sample_count) &&
            w3 == sizeof(float) * p_sample_count);
}

bool T20_recorderBegin(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return false;
    }

    if (!p->cfg.recorder.enable) {
        p->recorder.mounted = false;
        return true;
    }

    if (p->recorder.mounted) {
        return true;
    }

    if (!SD_MMC.begin()) {
        p->recorder.mounted = false;
        return false;
    }

    p->recorder.mounted = true;

    if (!SD_MMC.exists(p->cfg.recorder.root_dir)) {
        SD_MMC.mkdir(p->cfg.recorder.root_dir);
    }

    return true;
}

void T20_recorderEnd(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return;
    }

    if (p->recorder.session_open) {
        T20_recorderCloseSession(p);
    }

    p->recorder.mounted = false;
}

bool T20_recorderOpenSession(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return false;
    }

    if (!p->cfg.recorder.enable) {
        return true;
    }

    if (!p->recorder.mounted) {
        if (!T20_recorderBegin(p)) {
            return false;
        }
    }

    if (p->recorder.session_open) {
        return true;
    }

    p->recorder.session_index++;

    snprintf(p->recorder.session_dir,
             sizeof(p->recorder.session_dir),
             "%s/%s_%06lu",
             p->cfg.recorder.root_dir,
             p->cfg.recorder.session_prefix,
             (unsigned long)p->recorder.session_index);

    SD_MMC.mkdir(p->recorder.session_dir);

    snprintf(p->recorder.raw_path, sizeof(p->recorder.raw_path), "%s/raw.%s",
             p->recorder.session_dir,
             (p->cfg.recorder.raw_format == EN_T20_REC_RAW_CSV) ? "csv" : "bin");

    snprintf(p->recorder.cfg_path, sizeof(p->recorder.cfg_path), "%s/config.json",
             p->recorder.session_dir);

    snprintf(p->recorder.meta_path, sizeof(p->recorder.meta_path), "%s/metadata.%s",
             p->recorder.session_dir,
             (p->cfg.recorder.metadata_format == EN_T20_REC_META_CSV) ? "csv" : "jsonl");

    snprintf(p->recorder.event_path, sizeof(p->recorder.event_path), "%s/event.%s",
             p->recorder.session_dir,
             (p->cfg.recorder.event_format == EN_T20_REC_EVENT_CSV) ? "csv" : "jsonl");

    snprintf(p->recorder.feature_path, sizeof(p->recorder.feature_path), "%s/feature.csv",
             p->recorder.session_dir);

    memset(&p->recorder.raw_header, 0, sizeof(p->recorder.raw_header));
    p->recorder.raw_header.magic = G_T20_RAW_BINARY_MAGIC;
    p->recorder.raw_header.header_version = G_T20_RAW_BINARY_HEADER_VERSION;
    strncpy(p->recorder.raw_header.module_version, G_T20_VERSION_STR, sizeof(p->recorder.raw_header.module_version) - 1);
    p->recorder.raw_header.frame_size = p->cfg.feature.frame_size;
    p->recorder.raw_header.hop_size = p->cfg.feature.hop_size;
    p->recorder.raw_header.sample_rate_hz = p->cfg.feature.sample_rate_hz;
    p->recorder.raw_header.axis = (uint16_t)p->cfg.preprocess.axis;
    p->recorder.raw_header.mfcc_coeffs = p->cfg.feature.mfcc_coeffs;
    p->recorder.raw_header.mel_filters = p->cfg.feature.mel_filters;
    p->recorder.raw_header.delta_window = p->cfg.feature.delta_window;
    p->recorder.raw_header.session_start_ms = millis();

    p->recorder.raw_file = File();
    p->recorder.meta_file = File();
    p->recorder.event_file = File();
    p->recorder.feature_file = File();

    if (p->cfg.recorder.raw_format == EN_T20_REC_RAW_BINARY) {
        p->recorder.raw_file = SD_MMC.open(p->recorder.raw_path, FILE_WRITE);
    } else if (p->cfg.recorder.raw_format == EN_T20_REC_RAW_CSV) {
        p->recorder.raw_file = SD_MMC.open(p->recorder.raw_path, FILE_APPEND);
    }

    if (p->cfg.recorder.metadata_format != EN_T20_REC_META_NONE) {
        p->recorder.meta_file = SD_MMC.open(p->recorder.meta_path, FILE_APPEND);
    }

    if (p->cfg.recorder.event_format != EN_T20_REC_EVENT_NONE) {
        p->recorder.event_file = SD_MMC.open(p->recorder.event_path, FILE_APPEND);
    }

    if (p->cfg.recorder.write_feature_vector_csv) {
        p->recorder.feature_file = SD_MMC.open(p->recorder.feature_path, FILE_APPEND);
    }

    p->recorder.raw_dirty = false;
    p->recorder.meta_dirty = false;
    p->recorder.event_dirty = false;
    p->recorder.feature_dirty = false;
    p->recorder.queued_record_count = 0;
    p->recorder.written_record_count = 0;
    p->recorder.last_flush_ms = millis();
    p->recorder.last_metadata_ms = millis();

    p->recorder.session_open = true;

    if (p->cfg.recorder.raw_format == EN_T20_REC_RAW_BINARY) {
        if (!T20_recorderWriteBinaryHeader(p)) {
            T20_recorderCloseSession(p);
            return false;
        }
    }

    return true;
}

void T20_recorderCloseSession(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return;
    }

    T20_recorderFlushIfNeeded(p, true);

    if (p->recorder.raw_file) {
        p->recorder.raw_file.close();
    }
    if (p->recorder.meta_file) {
        p->recorder.meta_file.close();
    }
    if (p->recorder.event_file) {
        p->recorder.event_file.close();
    }
    if (p->recorder.feature_file) {
        p->recorder.feature_file.close();
    }

    p->recorder.session_open = false;
    p->recorder.raw_dirty = false;
    p->recorder.meta_dirty = false;
    p->recorder.event_dirty = false;
    p->recorder.feature_dirty = false;
}

bool T20_recorderWriteBinaryHeader(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr || !p->recorder.session_open || !p->recorder.raw_file) {
        return false;
    }

    size_t wrote = p->recorder.raw_file.write(
        reinterpret_cast<const uint8_t*>(&p->recorder.raw_header),
        sizeof(p->recorder.raw_header)
    );

    p->recorder.raw_dirty = true;
    return (wrote == sizeof(p->recorder.raw_header));
}

bool T20_recorderWriteConfig(CL_T20_Mfcc::ST_Impl* p, const ST_T20_Config_t* p_cfg)
{
    if (p == nullptr || p_cfg == nullptr || !p->cfg.recorder.enable || !p->recorder.session_open) {
        return false;
    }

    File f = SD_MMC.open(p->recorder.cfg_path, FILE_WRITE);
    if (!f) {
        return false;
    }

    f.println("{");
    f.printf("  \"version\": \"%s\",\n", G_T20_VERSION_STR);
    f.printf("  \"frame_size\": %u,\n", p_cfg->feature.frame_size);
    f.printf("  \"hop_size\": %u,\n", p_cfg->feature.hop_size);
    f.printf("  \"sample_rate_hz\": %.1f,\n", p_cfg->feature.sample_rate_hz);
    f.printf("  \"mel_filters\": %u,\n", p_cfg->feature.mel_filters);
    f.printf("  \"mfcc_coeffs\": %u,\n", p_cfg->feature.mfcc_coeffs);
    f.printf("  \"delta_window\": %u,\n", p_cfg->feature.delta_window);
    f.printf("  \"batch_count\": %u,\n", p_cfg->recorder.batch_count);
    f.printf("  \"flush_interval_ms\": %lu,\n", (unsigned long)p_cfg->recorder.flush_interval_ms);
    f.printf("  \"metadata_interval_ms\": %lu\n", (unsigned long)p_cfg->recorder.metadata_interval_ms);
    f.println("}");
    f.close();
    return true;
}

bool T20_recorderWriteMetadataHeartbeat(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr || !p->cfg.recorder.enable || !p->recorder.session_open) {
        return false;
    }

    if (!p->recorder.meta_file) {
        return false;
    }

    char line[256];
    if (p->cfg.recorder.metadata_format == EN_T20_REC_META_CSV) {
        snprintf(line, sizeof(line), "%lu,%lu,%lu,%lu,%u,%u",
                 (unsigned long)millis(),
                 (unsigned long)p->recorder.queued_record_count,
                 (unsigned long)p->recorder.written_record_count,
                 (unsigned long)p->recorder.dropped_record_count,
                 (unsigned)p->latest_feature.vector_len,
                 (unsigned)p->seq_rb.feature_dim);
    } else {
        snprintf(line, sizeof(line),
                 "{\"ts_ms\":%lu,\"queued\":%lu,\"written\":%lu,\"dropped\":%lu,\"vector_len\":%u,\"seq_dim\":%u}",
                 (unsigned long)millis(),
                 (unsigned long)p->recorder.queued_record_count,
                 (unsigned long)p->recorder.written_record_count,
                 (unsigned long)p->recorder.dropped_record_count,
                 (unsigned)p->latest_feature.vector_len,
                 (unsigned)p->seq_rb.feature_dim);
    }

    bool ok = T20_writeTextLineToOpenFile(p->recorder.meta_file, line);
    if (ok) {
        p->recorder.meta_dirty = true;
    }
    return ok;
}

bool T20_recorderWriteEvent(CL_T20_Mfcc::ST_Impl* p, const char* p_event_name)
{
    if (p == nullptr || p_event_name == nullptr || !p->cfg.recorder.enable || !p->recorder.session_open) {
        return false;
    }

    if (!p->recorder.event_file) {
        return false;
    }

    char line[192];
    if (p->cfg.recorder.event_format == EN_T20_REC_EVENT_CSV) {
        snprintf(line, sizeof(line), "%lu,%s", (unsigned long)millis(), p_event_name);
    } else {
        snprintf(line, sizeof(line), "{\"ts_ms\":%lu,\"event\":\"%s\"}",
                 (unsigned long)millis(), p_event_name);
    }

    bool ok = T20_writeTextLineToOpenFile(p->recorder.event_file, line);
    if (ok) {
        p->recorder.event_dirty = true;
    }
    return ok;
}

bool T20_recorderWriteRawFrame(CL_T20_Mfcc::ST_Impl* p, const float* p_frame, uint16_t p_len)
{
    if (p == nullptr || p_frame == nullptr || !p->cfg.recorder.enable || !p->recorder.session_open) {
        return false;
    }

    if (p->cfg.recorder.raw_format == EN_T20_REC_RAW_NONE) {
        return true;
    }

    if (!p->recorder.raw_file) {
        return false;
    }

    bool ok = false;

    if (p->cfg.recorder.raw_format == EN_T20_REC_RAW_BINARY) {
        ok = T20_writeBinaryRawRecordToOpenFile(p->recorder.raw_file, millis(), p_frame, p_len);
    } else {
        for (uint16_t i = 0; i < p_len; ++i) {
            p->recorder.raw_file.print(p_frame[i], 6);
            if (i + 1U < p_len) {
                p->recorder.raw_file.print(',');
            }
        }
        p->recorder.raw_file.println();
        ok = true;
    }

    if (ok) {
        p->recorder.raw_dirty = true;
    }
    return ok;
}

bool T20_recorderWriteFeature(CL_T20_Mfcc::ST_Impl* p, const ST_T20_FeatureVector_t* p_feature)
{
    if (p == nullptr || p_feature == nullptr || !p->cfg.recorder.enable || !p->recorder.session_open) {
        return false;
    }

    if (!p->cfg.recorder.write_feature_vector_csv) {
        return true;
    }

    if (!p->recorder.feature_file) {
        return false;
    }

    for (uint16_t i = 0; i < p_feature->vector_len; ++i) {
        p->recorder.feature_file.print(p_feature->vector[i], 6);
        if (i + 1U < p_feature->vector_len) {
            p->recorder.feature_file.print(',');
        }
    }
    p->recorder.feature_file.println();
    p->recorder.feature_dirty = true;
    return true;
}

void T20_recorderFlushIfNeeded(CL_T20_Mfcc::ST_Impl* p, bool p_force)
{
    if (p == nullptr || !p->recorder.session_open) {
        return;
    }

    uint32_t now_ms = millis();
    bool do_flush = p_force;

    if (!do_flush) {
        uint32_t interval_ms = p->cfg.recorder.flush_interval_ms;
        if (interval_ms == 0U) {
            interval_ms = G_T20_RECORDER_FLUSH_INTERVAL_MS;
        }
        do_flush = ((now_ms - p->recorder.last_flush_ms) >= interval_ms);
    }

    if (!do_flush) {
        return;
    }

    if (p->recorder.raw_dirty && p->recorder.raw_file) {
        p->recorder.raw_file.flush();
        p->recorder.raw_dirty = false;
    }
    if (p->recorder.meta_dirty && p->recorder.meta_file) {
        p->recorder.meta_file.flush();
        p->recorder.meta_dirty = false;
    }
    if (p->recorder.event_dirty && p->recorder.event_file) {
        p->recorder.event_file.flush();
        p->recorder.event_dirty = false;
    }
    if (p->recorder.feature_dirty && p->recorder.feature_file) {
        p->recorder.feature_file.flush();
        p->recorder.feature_dirty = false;
    }

    p->recorder.last_flush_ms = now_ms;
}

bool T20_recorderEnqueueEvent(CL_T20_Mfcc::ST_Impl* p, const char* p_event_name)
{
    if (p == nullptr || p_event_name == nullptr || p->recorder_queue == nullptr || !p->cfg.recorder.enable) {
        return false;
    }

    ST_T20_RecorderQueueItem_t item;
    memset(&item, 0, sizeof(item));
    item.record_type = EN_T20_REC_RECORD_EVENT;
    item.timestamp_ms = millis();
    strncpy(item.data.event_rec.text, p_event_name, sizeof(item.data.event_rec.text) - 1);

    if (xQueueSend(p->recorder_queue, &item, 0) == pdTRUE) {
        p->recorder.queued_record_count++;
        return true;
    }

    p->recorder.dropped_record_count++;
    return false;
}

bool T20_recorderEnqueueRawFrame(CL_T20_Mfcc::ST_Impl* p, const float* p_frame, uint16_t p_len)
{
    if (p == nullptr || p_frame == nullptr || p->recorder_queue == nullptr || !p->cfg.recorder.enable) {
        return false;
    }

    if (p_len == 0 || p_len > G_T20_RECORDER_RAW_MAX_SAMPLES) {
        return false;
    }

    ST_T20_RecorderQueueItem_t item;
    memset(&item, 0, sizeof(item));
    item.record_type = EN_T20_REC_RECORD_RAW_FRAME;
    item.timestamp_ms = millis();
    item.data.raw_rec.sample_count = p_len;
    memcpy(item.data.raw_rec.samples, p_frame, sizeof(float) * p_len);

    if (xQueueSend(p->recorder_queue, &item, 0) == pdTRUE) {
        p->recorder.queued_record_count++;
        return true;
    }

    p->recorder.dropped_record_count++;
    return false;
}

bool T20_recorderEnqueueFeature(CL_T20_Mfcc::ST_Impl* p, const ST_T20_FeatureVector_t* p_feature)
{
    if (p == nullptr || p_feature == nullptr || p->recorder_queue == nullptr || !p->cfg.recorder.enable) {
        return false;
    }

    ST_T20_RecorderQueueItem_t item;
    memset(&item, 0, sizeof(item));
    item.record_type = EN_T20_REC_RECORD_FEATURE;
    item.timestamp_ms = millis();
    item.data.feature_rec.feature = *p_feature;

    if (xQueueSend(p->recorder_queue, &item, 0) == pdTRUE) {
        p->recorder.queued_record_count++;
        return true;
    }

    p->recorder.dropped_record_count++;
    return false;
}

void T20_recorderTask(void* p_arg)
{
    CL_T20_Mfcc::ST_Impl* p = reinterpret_cast<CL_T20_Mfcc::ST_Impl*>(p_arg);
    ST_T20_RecorderVectorMessage_t v_pending[G_T20_RECORDER_BATCH_BUFFER_MAX];
    uint16_t v_pending_count = 0;
    uint32_t v_last_flush_ms = millis();

    for (;;) {
        if (!p->running) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }

        ST_T20_RecorderVectorMessage_t v_msg;
        BaseType_t v_rcv = xQueueReceive(p->recorder_queue,
                                         &v_msg,
                                         pdMS_TO_TICKS(20));

        if (v_rcv == pdTRUE) {
            if (v_pending_count < G_T20_RECORDER_BATCH_BUFFER_MAX) {
                v_pending[v_pending_count++] = v_msg;
            } else {
                T20_flushRecorderBatchMessages(p, v_pending, v_pending_count);
                v_pending_count = 0;
                v_pending[v_pending_count++] = v_msg;
            }
        }

        bool v_need_flush = false;

        if (v_pending_count >= G_T20_RECORDER_BATCH_ACCUM_WATERMARK) {
            v_need_flush = true;
        }

        if (v_pending_count > 0 &&
            (millis() - v_last_flush_ms) >= G_T20_RECORDER_BATCH_ACCUM_TIMEOUT_MS) {
            v_need_flush = true;
        }

        if (p->recorder_flush_requested || p->recorder_finalize_requested) {
            v_need_flush = true;
        }

        if (v_need_flush && v_pending_count > 0) {
            T20_flushRecorderBatchMessages(p, v_pending, v_pending_count);
            v_pending_count = 0;
            p->recorder_flush_requested = false;
            v_last_flush_ms = millis();
        }

        if (p->recorder_finalize_requested) {
            uint16_t v_drain = T20_drainRecorderQueue(p,
                                                      p->recorder_batch_msgs,
                                                      G_T20_RECORDER_BATCH_BUFFER_MAX);
            if (v_drain > 0) {
                T20_flushRecorderBatchMessages(p, p->recorder_batch_msgs, v_drain);
            }

            if (v_pending_count > 0) {
                T20_flushRecorderBatchMessages(p, v_pending, v_pending_count);
                v_pending_count = 0;
            }

            if (p->recorder_file_path[0] != 0) {
                File v_file = T20_openRecorderFileByBackend(p->recorder_storage_backend,
                                                            p->recorder_file_path,
                                                            "r+");
                if (v_file) {
                    T20_tryFinalizeRecorderBinarySession(p, v_file);
                    v_file.close();
                }
            }

            p->recorder_finalize_requested = false;
            p->recorder_flush_requested = false;
            v_last_flush_ms = millis();
        }

        vTaskDelay(pdMS_TO_TICKS(5));
    }
}


/*
TODO:
- recorder open/start 시 binary 모드에서 위 helper를 실제 호출하도록 연결
- record_count 갱신 및 close 시 header rewrite 지원
- payload 레코드 구조체 고정 및 endian/version 정책 확정
*/


bool T20_rewriteRecorderBinaryHeader(File& p_file, const ST_T20_RecorderBinaryHeader_t* p_hdr)
{
    if (!p_file || p_hdr == nullptr) {
        return false;
    }

    if (!p_file.seek(0, SeekSet)) {
        return false;
    }

    size_t v_written = p_file.write((const uint8_t*)p_hdr, sizeof(ST_T20_RecorderBinaryHeader_t));
    return (v_written == sizeof(ST_T20_RecorderBinaryHeader_t));
}

/*
===============================================================================
[040 단계 정리]
- binary header writer/rewrite helper를 recorder 계층에 배치
- 실제 open/start/stop 경로와의 강결합은 아직 부분 골격 상태
- 다음 단계에서 session state machine과 recorder lifecycle에 직접 연동 예정
===============================================================================

TODO:
- recorder open 경로에서 binary 모드일 때 T20_writeRecorderBinaryHeader 실제 호출
- recorder stop/flush 경로에서 record_count 반영 후 T20_rewriteRecorderBinaryHeader 호출
- payload write 구조를 ST_T20_RecorderBinaryRecord_t 기준으로 정식 고정
- status/event record kind 추가 및 metadata/event JSONL/CSV 동시 기록 정책 확정
*/


uint16_t T20_getRecorderBinaryVectorRecordBytes(uint16_t p_value_count)
{
    return (uint16_t)(sizeof(ST_T20_RecorderBinaryRecord_t) + sizeof(float) * p_value_count);
}

bool T20_writeRecorderBinaryVectorRecord(File& p_file,
                                         uint32_t p_timestamp_ms,
                                         const float* p_values,
                                         uint16_t p_value_count)
{
    if (!p_file || p_values == nullptr || p_value_count == 0) {
        return false;
    }

    ST_T20_RecorderBinaryRecord_t v_prefix;
    memset(&v_prefix, 0, sizeof(v_prefix));
    v_prefix.timestamp_ms = p_timestamp_ms;
    v_prefix.kind = G_T20_BINARY_RECORD_KIND_VECTOR;
    v_prefix.value_count = p_value_count;

    size_t v_written1 = p_file.write((const uint8_t*)&v_prefix, sizeof(v_prefix));
    if (v_written1 != sizeof(v_prefix)) {
        return false;
    }

    size_t v_written2 = p_file.write((const uint8_t*)p_values, sizeof(float) * p_value_count);
    if (v_written2 != (sizeof(float) * p_value_count)) {
        return false;
    }

    return true;
}

bool T20_tryOpenRecorderBinarySession(CL_T20_Mfcc::ST_Impl* p, const char* p_path)
{
    if (p == nullptr || p_path == nullptr) {
        return false;
    }

    File v_file = LittleFS.open(p_path, "w");
    if (!v_file) {
        return false;
    }

    bool v_ok = T20_writeRecorderBinaryHeader(v_file, &p->cfg);
    if (v_ok) {
        p->recorder_state = EN_T20_RECORDER_OPEN;
        p->recorder_record_count = 0;
        p->recorder_last_timestamp_ms = 0;
        p->recorder_batch_pending = 0;
        p->recorder_flush_count = 0;
        p->recorder_flush_requested = false;
        p->recorder_finalize_requested = false;
        p->recorder_storage_backend = EN_T20_STORAGE_LITTLEFS;
        strlcpy(p->recorder_file_path, p_path, sizeof(p->recorder_file_path));
    }
    v_file.close();
    return v_ok;
}

bool T20_tryFinalizeRecorderBinarySession(CL_T20_Mfcc::ST_Impl* p, File& p_file)
{
    if (p == nullptr || !p_file) {
        return false;
    }

    ST_T20_RecorderBinaryHeader_t v_hdr;
    memset(&v_hdr, 0, sizeof(v_hdr));
    v_hdr.magic[0] = 'T';
    v_hdr.magic[1] = '2';
    v_hdr.magic[2] = '0';
    v_hdr.magic[3] = 'B';
    v_hdr.version = G_T20_BINARY_HEADER_VERSION_SUPPORTED;
    v_hdr.header_size = sizeof(ST_T20_RecorderBinaryHeader_t);
    v_hdr.sample_rate_hz = (uint32_t)p->cfg.feature.sample_rate_hz;
    v_hdr.fft_size = p->cfg.feature.fft_size;
    v_hdr.mfcc_dim = p->cfg.feature.mfcc_coeffs;
    v_hdr.mel_filters = p->cfg.feature.mel_filters;
    v_hdr.sequence_frames = p->cfg.output.sequence_frames;
    v_hdr.record_count = p->recorder_record_count;

    bool v_ok = T20_rewriteRecorderBinaryHeader(p_file, &v_hdr);
    if (v_ok) {
        p->recorder_state = EN_T20_RECORDER_IDLE;
        p->recorder_batch_pending = 0;
        p->recorder_flush_requested = false;
        p->recorder_finalize_requested = false;
        if (p->recorder_storage_backend == EN_T20_STORAGE_SDMMC) {
            T20_unmountSdmmcRecorderBackend(p);
        }
        p->recorder_storage_backend = EN_T20_STORAGE_LITTLEFS;
        memset(p->recorder_file_path, 0, sizeof(p->recorder_file_path));
    }
    return v_ok;
}

/*
TODO:
- 실제 recorder task/queue와 연결해 batch flush 단위로 본 helper 호출
- SD_MMC 경로와 LittleFS preview 경로를 공통 writer 인터페이스로 추상화
- vector 외 status/event record kind를 추가하고 payload decode를 완성
*/


bool T20_flushRecorderVectorBatch(CL_T20_Mfcc::ST_Impl* p,
                                  const float* p_vector,
                                  uint16_t p_vector_len,
                                  uint32_t p_timestamp_ms)
{
    if (p == nullptr || p_vector == nullptr || p_vector_len == 0) {
        return false;
    }

    ST_T20_RecorderVectorMessage_t v_msg;
    memset(&v_msg, 0, sizeof(v_msg));
    v_msg.timestamp_ms = p_timestamp_ms;
    v_msg.vector_len = p_vector_len;
    memcpy(v_msg.vector, p_vector, sizeof(float) * p_vector_len);

    return T20_flushRecorderBatchMessages(p, &v_msg, 1);
}

/*
TODO:
- recorder batch queue를 별도 queue/task로 분리
- flush 조건(개수/시간/stop 이벤트) 기반으로 batch write 최적화
- SD_MMC writer와 LittleFS writer를 공통 인터페이스로 묶기
*/


bool T20_createRecorderObjects(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return false;
    }

    if (p->recorder_queue == nullptr) {
        p->recorder_queue = xQueueCreate(G_T20_RECORDER_QUEUE_LEN, sizeof(ST_T20_RecorderVectorMessage_t));
    }

    return (p->recorder_queue != nullptr);
}

void T20_releaseRecorderObjects(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return;
    }

    if (p->recorder_queue != nullptr) {
        vQueueDelete(p->recorder_queue);
        p->recorder_queue = nullptr;
    }
}

bool T20_enqueueRecorderVector(CL_T20_Mfcc::ST_Impl* p,
                               const float* p_vector,
                               uint16_t p_vector_len,
                               uint32_t p_timestamp_ms)
{
    if (p == nullptr || p_vector == nullptr || p_vector_len == 0) {
        return false;
    }

    if (p->recorder_queue == nullptr) {
        return false;
    }

    if (p_vector_len > G_T20_FEATURE_DIM_MAX) {
        return false;
    }

    ST_T20_RecorderVectorMessage_t v_msg;
    memset(&v_msg, 0, sizeof(v_msg));
    v_msg.timestamp_ms = p_timestamp_ms;
    v_msg.vector_len = p_vector_len;
    memcpy(v_msg.vector, p_vector, sizeof(float) * p_vector_len);

    if (xQueueSend(p->recorder_queue, &v_msg, 0) != pdTRUE) {
        /* 큐가 가득 찼으면 가장 오래된 항목을 버리고 최신 항목 우선 */
        ST_T20_RecorderVectorMessage_t v_old;
        if (xQueueReceive(p->recorder_queue, &v_old, 0) == pdTRUE) {
            p->dropped_frames++;
            if (xQueueSend(p->recorder_queue, &v_msg, 0) == pdTRUE) {
                p->recorder_batch_pending++;
                return true;
            }
        }
        return false;
    }

    p->recorder_batch_pending++;
    return true;
}

void T20_recorderTask(void* p_arg)
{
    CL_T20_Mfcc::ST_Impl* p = reinterpret_cast<CL_T20_Mfcc::ST_Impl*>(p_arg);
    ST_T20_RecorderVectorMessage_t v_msg;
    uint32_t v_last_flush_ms = millis();

    for (;;) {
        BaseType_t v_rcv = xQueueReceive(p->recorder_queue,
                                         &v_msg,
                                         pdMS_TO_TICKS(G_T20_RECORDER_FLUSH_INTERVAL_MS));

        if (!p->running) {
            continue;
        }

        if (v_rcv == pdTRUE) {
            T20_flushRecorderVectorBatch(p,
                                         v_msg.vector,
                                         v_msg.vector_len,
                                         v_msg.timestamp_ms);
            v_last_flush_ms = millis();
        } else {
            /* 주기적 flush 시그널용 자리 */
            if (p->recorder_flush_requested ||
                (millis() - v_last_flush_ms) >= G_T20_RECORDER_FLUSH_INTERVAL_MS) {
                p->recorder_flush_requested = false;
                p->recorder_flush_count++;
                v_last_flush_ms = millis();
            }
        }
    }
}

/*
TODO:
- recorder queue/task를 LittleFS + SD_MMC 공통 writer 인터페이스로 일반화
- 배치 메모리 묶음 write로 실제 flush 최적화
- stop() 또는 세션 종료 시 queue drain 후 finalize 보장
*/


File T20_openRecorderFileByBackend(EM_T20_StorageBackend_t p_backend,
                                   const char* p_path,
                                   const char* p_mode)
{
    if (p_path == nullptr || p_mode == nullptr) {
        return File();
    }

    if (p_backend == EN_T20_STORAGE_LITTLEFS) {
        return LittleFS.open(p_path, p_mode);
    }

    /*
     * SD_MMC backend 실제 경로 연결
     * - p_path는 '/sdcard/...' 형식 사용 권장
     * TODO:
     * - 보드별 mount/pin/mode 설정 분리
     * - open 실패 원인별 진단 상태 추가
     */
    return SD_MMC.open(p_path, p_mode);
}

bool T20_flushRecorderBatchMessages(CL_T20_Mfcc::ST_Impl* p,
                                    const ST_T20_RecorderVectorMessage_t* p_msgs,
                                    uint16_t p_count)
{
    if (p == nullptr || p_msgs == nullptr || p_count == 0) {
        return false;
    }

    if (p->recorder_file_path[0] == 0) {
        return false;
    }

    File v_file = T20_openRecorderFileByBackend(p->recorder_storage_backend,
                                                p->recorder_file_path,
                                                "a");
    if (!v_file) {
        return false;
    }

    bool v_all_ok = true;
    for (uint16_t i = 0; i < p_count; ++i) {
        bool v_ok = T20_writeRecorderBinaryVectorRecord(v_file,
                                                        p_msgs[i].timestamp_ms,
                                                        p_msgs[i].vector,
                                                        p_msgs[i].vector_len);
        if (!v_ok) {
            v_all_ok = false;
            break;
        }

        p->recorder_state = EN_T20_RECORDER_RECORDING;
        p->recorder_record_count++;
        p->recorder_last_timestamp_ms = p_msgs[i].timestamp_ms;
        if (p->recorder_batch_pending > 0) {
            p->recorder_batch_pending--;
        }
    }

    v_file.flush();
    v_file.close();

    if (v_all_ok) {
        p->recorder_flush_count++;
    }

    return v_all_ok;
}

uint16_t T20_drainRecorderQueue(CL_T20_Mfcc::ST_Impl* p,
                                ST_T20_RecorderVectorMessage_t* p_msgs,
                                uint16_t p_capacity)
{
    if (p == nullptr || p_msgs == nullptr || p_capacity == 0 || p->recorder_queue == nullptr) {
        return 0;
    }

    uint16_t v_count = 0;
    while (v_count < p_capacity) {
        if (xQueueReceive(p->recorder_queue, &p_msgs[v_count], 0) != pdTRUE) {
            break;
        }
        v_count++;
    }
    return v_count;
}


/*
TODO:
- zero-copy / DMA / cache aligned 최적화는 recorder batch write 경로 안정화 후 적용
- SD_MMC backend 실제 구현 시 LittleFS와 동일한 writer contract 유지
- batch 누적 메모리와 flush watermark를 실제 I/O 벤치 기준으로 재조정
*/


bool T20_tryMountSdmmcRecorderBackend(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return false;
    }

    if (p->recorder_sdmmc_mounted) {
        return true;
    }

    bool v_ok = SD_MMC.begin("/sdcard", true);
    if (!v_ok) {
        p->recorder_sdmmc_mounted = false;
        return false;
    }

    p->recorder_sdmmc_mounted = true;
    strlcpy(p->recorder_sdmmc_mount_path, G_T20_SDMMC_MOUNT_PATH_DEFAULT, sizeof(p->recorder_sdmmc_mount_path));
    return true;
}

void T20_unmountSdmmcRecorderBackend(CL_T20_Mfcc::ST_Impl* p)
{
    if (p == nullptr) {
        return;
    }

    if (p->recorder_sdmmc_mounted) {
        SD_MMC.end();
        p->recorder_sdmmc_mounted = false;
    }
}


/*
TODO:
- batch 누적 버퍼를 DMA/cache aligned 메모리 풀 기반으로 전환
- SD_MMC write size를 sector/block 크기에 맞춘 묶음 write로 최적화
- chart render sync용 downsample cache와 recorder preview cache 연계
*/
